let score = 0;
let bonusMode = false;
const choicesBox = document.getElementById("choices");
const choices = document.querySelectorAll(".choice");
const scoreText = document.getElementById("score");
const result = document.getElementById("result");
const playerChoice = document.getElementById("player-choice");
const computerChoice = document.getElementById("computer-choice");
const message = document.getElementById("message");
const playAgain = document.getElementById("play-again");
const modeButton = document.getElementById("mode-button");
const logo = document.getElementById("logo");
const rulesButton = document.getElementById("rules-button");
const rules = document.getElementById("rules");
const closeRules = document.getElementById("close-rules");
const rulesImage = document.getElementById("rules-image");

choices.forEach(function(button) {
    button.addEventListener("click", function() {
        let player = button.dataset.choice;
        let computer = getComputerChoice();
        showChoices(player, computer);
        checkWinner(player, computer);
        choicesBox.style.display = "none";
        result.style.display = "flex";
    });
});
function getComputerChoice() {
    let options;
    if (bonusMode) {
        options = ["rock", "paper", "scissors", "lizard", "spock"];
    } else {
        options = ["rock", "paper", "scissors"];
    }
    let randomNumber = Math.floor(Math.random() * options.length);
    return options[randomNumber];
}
function showChoices(player, computer) {
    playerChoice.innerHTML = '<img src="images/icon-' + player + '.svg">';
    computerChoice.innerHTML = '<img src="images/icon-' + computer + '.svg">';
}
function checkWinner(player, computer) {
    if (player === computer) {
        message.textContent = "DRAW";
        return;
    }
    if (bonusMode) {
        checkBonusWinner(player, computer);
    } else {
        checkNormalWinner(player, computer);
    }
    scoreText.textContent = score;
}
function checkNormalWinner(player, computer) {
    if (
        (player === "rock" && computer === "scissors") ||
        (player === "paper" && computer === "rock") ||
        (player === "scissors" && computer === "paper")
    ) {
        message.textContent = "YOU WIN";
        score++;
    } else {
        message.textContent = "YOU LOSE";
        score--;
    }
}
function checkBonusWinner(player, computer) {
    if (
        (player === "rock" && (computer === "scissors" || computer === "lizard")) ||
        (player === "paper" && (computer === "rock" || computer === "spock")) ||
        (player === "scissors" && (computer === "paper" || computer === "lizard")) ||
        (player === "lizard" && (computer === "paper" || computer === "spock")) ||
        (player === "spock" && (computer === "rock" || computer === "scissors"))
    ) {
        message.textContent = "YOU WIN";
        score++;
    } else {
        message.textContent = "YOU LOSE";
        score--;
    }
}
playAgain.addEventListener("click", function() {
    choicesBox.style.display = "block";
    result.style.display = "none";
});
modeButton.addEventListener("click", function() {
    bonusMode = !bonusMode;
    if (bonusMode) {
        choicesBox.classList.remove("normal-mode");
        choicesBox.classList.add("bonus-mode");
        logo.src = "images/logo-bonus.svg";
        modeButton.textContent = "NORMAL MODE";
        rulesImage.src = "images/image-rules-bonus.svg";
    } else {
        choicesBox.classList.remove("bonus-mode");
        choicesBox.classList.add("normal-mode");
        logo.src = "images/logo.svg";
        modeButton.textContent = "BONUS MODE";
        rulesImage.src = "images/image-rules.svg";
    }
});
rulesButton.addEventListener("click", function() {
    rules.style.display = "flex";
});
closeRules.addEventListener("click", function() {
    rules.style.display = "none";
});